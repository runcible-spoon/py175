# Python is...

A dynamic, **open source** programming language with a focus on
_simplicity_ and _productivity_. It has an elegant syntax that
is natural to read and easy to write.
